(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var Auth0 = Package['mrt:auth0'].Auth0;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/mrt_accounts-auth0/packages/mrt_accounts-auth0.js                                                //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
(function () {                                                                                               // 1
                                                                                                             // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                                     //    // 4
// packages/mrt:accounts-auth0/auth0.js                                                                //    // 5
//                                                                                                     //    // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                                       //    // 8
Accounts.oauth.registerService('auth0');                                                               // 1  // 9
                                                                                                       // 2  // 10
if (Meteor.isClient) {                                                                                 // 3  // 11
  Meteor.loginWithAuth0 = function (options, callback) {                                               // 4  // 12
                                                                                                       // 5  // 13
    if (! callback && typeof options === 'function') {                                                 // 6  // 14
      callback = options;                                                                              // 7  // 15
      options = null;                                                                                  // 8  // 16
    }                                                                                                  // 9  // 17
                                                                                                       // 10
    var credentialRequestCompleteCallback = Accounts.oauth.credentialRequestCompleteHandler(callback); // 11
    Auth0.requestCredential(options, credentialRequestCompleteCallback);                               // 12
  };                                                                                                   // 13
}                                                                                                      // 14
else {                                                                                                 // 15
  Accounts.addAutopublishFields({                                                                      // 16
    forLoggedInUser: ['services.auth0'],                                                               // 17
    forOtherUsers: ['services.auth0.id']                                                               // 18
  });                                                                                                  // 19
}                                                                                                      // 20
                                                                                                       // 21
/////////////////////////////////////////////////////////////////////////////////////////////////////////    // 30
                                                                                                             // 31
}).call(this);                                                                                               // 32
                                                                                                             // 33
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:accounts-auth0'] = {};

})();

//# sourceMappingURL=mrt_accounts-auth0.js.map
