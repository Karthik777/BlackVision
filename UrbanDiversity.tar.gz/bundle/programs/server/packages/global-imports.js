/* Imports for global scope */

MeteorCamera = Package['mdg:camera'].MeteorCamera;
Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
gm = Package['cfs:graphicsmagick'].gm;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Log = Package.logging.Log;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
ReactiveVar = Package['reactive-var'].ReactiveVar;
ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
Iron = Package['iron:core'].Iron;
FS = Package['cfs:base-package'].FS;
Accounts = Package['accounts-base'].Accounts;
AccountsServer = Package['accounts-base'].AccountsServer;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;

