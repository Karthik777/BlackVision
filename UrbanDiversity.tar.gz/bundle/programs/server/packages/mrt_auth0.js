(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var OAuth = Package.oauth.OAuth;
var Oauth = Package.oauth.Oauth;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;

/* Package-scope variables */
var Auth0;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt_auth0/packages/mrt_auth0.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function () {                                                                                                        // 1
                                                                                                                      // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                                                             //     // 4
// packages/mrt:auth0/auth0_server.js                                                                          //     // 5
//                                                                                                             //     // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                                               //     // 8
Auth0 = {};                                                                                                    // 1   // 9
                                                                                                               // 2   // 10
Oauth.registerService('auth0', 2, null, function (query) {                                                     // 3   // 11
                                                                                                               // 4   // 12
  var tokens = getTokens(query);                                                                               // 5   // 13
  var user = getUserProfile(tokens.access_token);                                                              // 6   // 14
                                                                                                               // 7   // 15
  var username = user.name || user.email;                                                                      // 8   // 16
  var serviceData = {                                                                                          // 9   // 17
    id:           user.user_id,                                                                                // 10  // 18
    accessToken:  tokens.access_token,                                                                         // 11  // 19
    id_token:     tokens.id_token,                                                                             // 12  // 20
    name:         username                                                                                     // 13  // 21
  };                                                                                                           // 14  // 22
                                                                                                               // 15  // 23
  _.extend(serviceData, user);                                                                                 // 16  // 24
                                                                                                               // 17  // 25
  return {                                                                                                     // 18  // 26
    serviceData: serviceData,                                                                                  // 19  // 27
    options: {                                                                                                 // 20  // 28
      profile: {                                                                                               // 21  // 29
        name: username                                                                                         // 22  // 30
      }                                                                                                        // 23  // 31
    }                                                                                                          // 24  // 32
  };                                                                                                           // 25  // 33
});                                                                                                            // 26  // 34
                                                                                                               // 27  // 35
var userAgent = 'Meteor';                                                                                      // 28  // 36
if (Meteor.release) {                                                                                          // 29  // 37
  userAgent += '/' + Meteor.release;                                                                           // 30  // 38
}                                                                                                              // 31  // 39
                                                                                                               // 32  // 40
var getTokens = function (query) {                                                                             // 33  // 41
  var config = getConfiguration();                                                                             // 34  // 42
  var response;                                                                                                // 35  // 43
  try {                                                                                                        // 36  // 44
                                                                                                               // 37  // 45
    response = HTTP.post(                                                                                      // 38  // 46
      'https://' + config.domain + '/oauth/token', {                                                           // 39  // 47
        headers: {                                                                                             // 40  // 48
          Accept: 'application/json',                                                                          // 41  // 49
          'User-Agent': userAgent                                                                              // 42  // 50
        },                                                                                                     // 43  // 51
        params: {                                                                                              // 44  // 52
          code:           query.code,                                                                          // 45  // 53
          //state:          query.state,                                                                       // 46  // 54
          client_id:      config.clientId,                                                                     // 47  // 55
          client_secret:  config.clientSecret,                                                                 // 48  // 56
          grant_type:     'authorization_code',                                                                // 49  // 57
          redirect_uri:   Meteor.absoluteUrl('_oauth/auth0')                                                   // 50  // 58
        }                                                                                                      // 51  // 59
      });                                                                                                      // 52  // 60
  }                                                                                                            // 53  // 61
  catch (err) {                                                                                                // 54  // 62
    throw _.extend(                                                                                            // 55  // 63
      new Error('Failed to complete OAuth handshake with Auth0. ' + err.message), { response: err.response }); // 56  // 64
  }                                                                                                            // 57  // 65
                                                                                                               // 58  // 66
  if (response.data.error) { // if the http response was a json object with an error attribute                 // 59  // 67
    throw new Error('Failed to complete OAuth handshake with Auth0. ' + response.data.error);                  // 60  // 68
  }                                                                                                            // 61  // 69
                                                                                                               // 62  // 70
  return response.data;                                                                                        // 63  // 71
};                                                                                                             // 64  // 72
                                                                                                               // 65  // 73
var getUserProfile = function (accessToken) {                                                                  // 66  // 74
  var config = getConfiguration();                                                                             // 67  // 75
  var response;                                                                                                // 68  // 76
  try {                                                                                                        // 69  // 77
    response = HTTP.get(                                                                                       // 70  // 78
      'https://' + config.domain + '/userinfo', {                                                              // 71  // 79
        headers: {                                                                                             // 72  // 80
          'User-Agent': userAgent                                                                              // 73  // 81
        },                                                                                                     // 74  // 82
        params: {                                                                                              // 75  // 83
          access_token: accessToken                                                                            // 76  // 84
        }                                                                                                      // 77  // 85
      });                                                                                                      // 78  // 86
  }                                                                                                            // 79  // 87
  catch (err) {                                                                                                // 80  // 88
    throw _.extend(                                                                                            // 81  // 89
      new Error('Failed to fetch user profile from Auth0. ' + err.message), { response: err.response });       // 82  // 90
  }                                                                                                            // 83  // 91
                                                                                                               // 84  // 92
  return response.data;                                                                                        // 85  // 93
};                                                                                                             // 86  // 94
                                                                                                               // 87  // 95
var getConfiguration = function () {                                                                           // 88  // 96
  var config = ServiceConfiguration.configurations.findOne({ service: 'auth0' });                              // 89  // 97
  if (!config) {                                                                                               // 90  // 98
    throw new ServiceConfiguration.ConfigError('Service not configured.');                                     // 91  // 99
  }                                                                                                            // 92  // 100
                                                                                                               // 93  // 101
  return config;                                                                                               // 94  // 102
};                                                                                                             // 95  // 103
                                                                                                               // 96  // 104
Auth0.retrieveCredential = function(credentialToken) {                                                         // 97  // 105
  return Oauth.retrieveCredential(credentialToken);                                                            // 98  // 106
};                                                                                                             // 99  // 107
                                                                                                               // 100
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 109
                                                                                                                      // 110
}).call(this);                                                                                                        // 111
                                                                                                                      // 112
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:auth0'] = {
  Auth0: Auth0
};

})();

//# sourceMappingURL=mrt_auth0.js.map
